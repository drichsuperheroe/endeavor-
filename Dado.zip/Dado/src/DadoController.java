import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import java.util.Random;
import javafx.scene.image.Image;

public class DadoController {

    @FXML
    private ImageView DadoImage;
    Random random = new Random();

    @FXML
    private Label NumberRolled;

    @FXML
    void Tirar(ActionEvent event) {
        int number = random.nextInt(6)+1;
        if(number == 1){DadoImage.setImage(new Image("cara1.png"));}
        if(number == 2){DadoImage.setImage(new Image("cara2.png"));}
        if(number == 3){DadoImage.setImage(new Image("cara3.png"));}
        if(number == 4){DadoImage.setImage(new Image("cara4.png"));}
        if(number == 5){DadoImage.setImage(new Image("cara5.png"));}
        if(number == 6){DadoImage.setImage(new Image("cara6.png"));}
        NumberRolled.setText(String.valueOf(number));

        

    }

}
